
$start_bot_multi = "mu-on";
$stop_bot_multi = "mu-off";

$nitroflare_on  = "nitroflare on";
$nitroflare_off = "nitroflare off";

$secureupload_on  = "secureupload on";
$secureupload_off = "secureupload off";

$salefiles_on  = "salefiles on";
$salefiles_off = "salefiles off";

$fshare_on        = "fshare on";
$fshare_off       = "fshare off";

$kingfiles_on        = "kingfiles on";
$kingfiles_off       = "kingfiles off";

$wushare_on        = "wushare on";
$wushare_off       = "wushare off";

$filespace_on        = "filespace on";
$filespace_off       = "filespace off";


$shareonline_off = "share-online off";
$shareonline_on  = "share-online on";

$foursharevn_on      = "4share on";
$foursharevn_off     = "4share off";


$sharevnn_on  = "svnn-on";
$sharevnn_off = "svnn-off";

$tenluavn_on  = "tenlua on";
$tenluavn_off = "tenlua off";

$upfilevn_on  = "upfile on";
$upfilevn_off = "upfile off";

$mediafire_on  = "mediafire on";
$mediafire_off = "mediafire off";

$netload_on  = "netload on";
$netload_off = "netload off";

$uploaded_on  = "uploaded on";
$uploaded_off = "uploaded off";

$rapidgator_on  = "rapidgator on";
$rapidgator_off = "rapidgator off";

$hitfile_on  = "hitfile on";
$hitfile_off = "hitfile off";

$letitbit_on  = "letitbit on";
$letitbit_off = "letitbit off";

$novafile_on  = "novafile on";
$novafile_off = "novafile off";

$turbobit_on  = "turbobit on";
$turbobit_off = "turbobit off";

$ryushare_on  = "ryushare on";
$ryushare_off = "ryushare off";

$filefactory_on  = "filefactory on";
$filefactory_off = "filefactory off";

$filepost_on  = "filepost on";
$filepost_off = "filepost off";

$fourshared_on  = "4shared on";
$fourshared_off = "4shared off";

$depositfiles_on  = "depositfiles on";
$depositfiles_off = "depositfiles off";

$terafile_on  = "terafile on";
$terafile_off = "terafile off";

$oboom_on  = "oboom on";
$oboom_off = "oboom off";

$bitshare_on  = "bitshare on";
$bitshare_off = "bitshare off";

$uptobox_on  = "uptobox on";
$uptobox_off = "uptobox off";

$extmatrix_on  = "extmatrix on";
$extmatrix_off = "extmatrix off";

$megaconz_on  = "mega.co.nz on";
$megaconz_off = "mega.co.nz off";

$freakshare_on  = "freakshare on";
$freakshare_off = "freakshare off";

$firedrive_on  = "firedrive on";
$firedrive_off = "firedrive off";

$uploadable_on  = "uploadable on";
$uploadable_off = "uploadable off";

$zippyshare_on  = "zippyshare on";
$zippyshare_off = "zippyshare off";

$keep2share_on  = "keep2share on";
$keep2share_off = "keep2share off";

$megashares_on  = "megashares on";
$megashares_off = "megashares off";

$youtube_on  = "youtube on";
$youtube_off = "youtube off";

$onefichiercom_off = "1fichier off";
$onefichiercom_on = "1fichier on";

$sendspacecom_off = "sendspace off";
$sendspacecom_on = "sendspace on";

$yunfilecom_off = "yunfile off";
$yunfilecom_on = "yunfile on";

$shareflare_off = "shareflare off";
$shareflare_on = "shareflare on";

$nowdownload_off = "nowdownload off";
$nowdownload_on = "nowdownload on ";

$vipfile_on = "vip-file on";
$vipfile_off = "vip-file off";

$uploading_off = "uploading off";
$uploading_on = "uploading on";

$depfile_off = "depfile off";
$depfile_on = "depfile on";

$filesmonster_off = "filesmonster off";
$filesmonster_on = "filesmonster on";

$datafile_off = "datafile off";
$datafile_on = "datafile on";

$ulto_off = "ulto off";
$ulto_on = "ulto on";

$speedyshare_off = "speedyshare off";
$speedyshare_on = "speedyshare on";

$tusfiles_off = "tusfiles off";
$tusfiles_on = "tusfiles on";

$scribd_off = "scribd off";
$scribd_on = "scribd on";

$hugefiles_off = "hugefiles off";
$hugefiles_on = "hugefiles on";

$filesflash_off = "filesflash off";
$filesflash_on = "filesflash on";

$soundcloud_off = "soundcloud off";
$soundcloud_on = "soundcloud on";

$subyshare_off = "subyshare off";
$subyshare_on = "subyshare on";

$littlebyte_on = "littlebyte on";
$littlebyte_off = "littlebyte off";


$check_support = "ken sp";

$check_manager  = "check-mng";
$add_manager    = "add-mng";
$remove_manager = "del-mng";

$add_vip    = "add_vip";
$remove_vip = "del_vip";

$check_bot  = "check-bot";
$add_bot    = "add-bot";
$remove_bot = "del-bot";



$start_bot = "vip on";
$stop_bot  = "vip off";

$start_chat = "chat on";
$stop_chat  = "chat off";

$start_talk = "talk on";
$stop_talk  = "talk off";

$start_ziplink = "zip on";
$stop_ziplink  = "zip off";
