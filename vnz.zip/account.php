<?php

$account = array(
# Example: 'accounts'	=> array('user:pass','cookie'),
# Example with letitbit.net: 'accounts'    => array('user:pass','cookie','prekey=xxxx'),


	'rapidgator.net'		=> array(
								'accounts'	=> array('german@3kbits.com.ar:socrates2008',),
							),

);

?>